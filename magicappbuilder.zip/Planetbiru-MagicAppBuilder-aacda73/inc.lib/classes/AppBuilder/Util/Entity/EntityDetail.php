<?php

namespace AppBuilder\Util\Entity;

class EntityDetail
{

}
<?php

$themeAssetsPath = "lib.themes/$appCurrentTheme/assets/";

require_once dirname(__DIR__) . "/lib.themes/$appCurrentTheme/header.php";

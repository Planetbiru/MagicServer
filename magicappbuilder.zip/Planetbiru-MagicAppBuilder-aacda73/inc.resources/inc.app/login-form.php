<?php

$themeAssetsPath = "lib.themes/$appCurrentTheme/assets/";

require_once __DIR__ . "/default-language.php";
require_once dirname(__DIR__) . "/lib.themes/$appCurrentTheme/login-form.php";

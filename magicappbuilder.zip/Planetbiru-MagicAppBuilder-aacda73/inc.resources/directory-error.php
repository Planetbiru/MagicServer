<?php

require_once __DIR__ . '/inc.app/directory-error.php';
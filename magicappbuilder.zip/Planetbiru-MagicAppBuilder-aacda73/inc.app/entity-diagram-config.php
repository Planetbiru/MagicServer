<?php

$entityDiagramConfig = new stdClass();

$entityDiagramConfig->gapX = 40;
$entityDiagramConfig->gapY = 20;
$entityDiagramConfig->minimumZoom = 0.25;
$entityDiagramConfig->diagramWidth = 225;
